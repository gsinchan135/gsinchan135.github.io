﻿function Bamboozle()
{
    $filePath = [string](Get-Location)

    $randomLetter = [char]((65..90) | Get-Random)

    Write-Host -ForegroundColor Green "bread"
    Write-Host -NoNewline -ForegroundColor Green "Any files with the letter "
    Write-Host -NoNewline -ForegroundColor Magenta $randomLetter
    Write-Host -NoNewline -ForegroundColor Green " have been removed."

    Get-ChildItem *$randomLetter**.* | remove-item -WhatIf
    
}
Bamboozle